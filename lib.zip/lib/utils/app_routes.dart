import 'package:flutter/material.dart';
import 'package:umair_liaqat/ui/home/home_screen.dart';

final Map<String, WidgetBuilder> routes = {
  HomeScreen.routeName: (_) => const HomeScreen()
};

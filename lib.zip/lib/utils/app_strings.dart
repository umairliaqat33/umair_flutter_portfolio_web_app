class AppStrings {
  static const String resume =
      'https://drive.google.com/file/d/1ON4gsfxDJSGv6qJzI0CkDB65muAu5dik/view?usp=sharing';
  static const String cv =
      'https://drive.google.com/file/d/1hsqVAIV0WZTa5ZO5IWjfgX8qIF4yYycD/view?usp=sharing';
  static const String whatsapp =
      'https://api.whatsapp.com/send?phone=923134146206';
  static const String linkedIn =
      'https://www.linkedin.com/in/umair-liaqat-305450228/';
  static const String github = 'https://github.com/umairliaqat33';
}
